<?php
    $host = 'mandatory2.cvthsfx2t9d7.us-east-1.rds.amazonaws.com';
    $db = 'chinook_abridged';
    $user = 'root';
    $pwd = 'Stef2761';
?>